const CONFIG = {
nama: "TS SHOP", // Nama Store
profil: "https://files.catbox.moe/muwv46.jpg", // Url Profil
banner: "https://files.catbox.moe/9gr5z6.jpeg", // Url Banner 
tentang: "TS SHOP adalah toko online terpercaya yang telah melayani ribuan pelanggan sejak 2025. Kami menyediakan berbagai produk digital untuk kebutuhan sehari-hari dengan kualitas terbaik dan harga terjangkau.\n\nKomitmen kami adalah memberikan pengalaman berbelanja yang menyenangkan dengan pelayanan terbaik, produk original, dan garansi resmi untuk semua produk yang kami jual.",
alamat: "Jl. Contoh No. 123, Jakarta, Indonesia",
sosial_media: {
  email: "faizaladla09@gmail.com", // Email
  youtube: "zassci_desu", // YouTube Username 
  tiktok: "zass.id", // Tiktok Username 
  whatsapp: "6287849796357", // WhatsApp Number 
  telegram: "Paiz344" // Telegram Username
},
payment: {
  dana: "082313148928", // Payment Dana
  gopay: "087849796357", // Payment Gopay 
  ovo: "087849796357", // Payment Ovo 
  qris: "https://linkqr.kamu.mom" // Url Qris
},
telegram_api: {
  bot: "8323788571:AAEl3uYvU6vNDObWzSHtraDJHdVYvyEzIMQ", // Token bot father
  chatid: "-4882822688" // ID telegram
},
}

// Produk
const productsData = {
            "produk digital": [
              {
                    id: 1,
                    name: "Akun Premium",
                    icon: "fas fa-user-circle",
                    description: "Berbagai akun premium dengan harga terjangkau, cocok untuk hiburan dan produktivitas.",
                    variants: [
                        { name: "Netflix Premium (1 Bulan)", price: 35000 },
                        { name: "Spotify Premium (1 Bulan)", price: 25000 },
                        { name: "Canva Pro (1 Bulan)", price: 20000 }
                         {name: "YouTube premium (1 bulan)", price: 10000}                     
                    ]
                }
            ]
        };